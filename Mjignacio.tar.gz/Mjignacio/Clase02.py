'''
Created on 27 ago. 2016

@author: Jignacio
'''
def Agregar(nombre,lista):
    lista.append(nombre)

def Borrar(nombre,lista):
    lista.remove(nombre)

if __name__=="__main__":        
    flag=True
    nombre=""
    lista=[]
    while(flag):
        opcion=int(input("Ingrese opcion\n1.Agregar \n2.Borrar \n3.Salir"))
        if(opcion==1):
            nombre=input("Nombre")
            Agregar(nombre,lista)
        elif(opcion==2):
            nombre=input("Nombre")  
            if(nombre in lista):
                Borrar(nombre, lista)
            else:
                print("No esta registrado")   
        elif(opcion==3):
            flag=False
        print(lista)
            